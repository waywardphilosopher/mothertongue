FOLDER CONTENTS:

--README.txt
--Taigael-Advance Information.pdf
--About Wind&Bones.pdf

--Wind&Bones Images [SUB-FOLDER]
----logo-2025.png
----logo-2025-muted.png
----Hannah Stevens and Will Buckingham.jpeg
----Hannah Stevens and Will Buckingham 1.jpeg

--Book Cover [SUB-FOLDER]
---Taigae-cover.jpg

--Author and Translator Photos [SUB-FOLDER]
----Naomi Sim.jpg
----Lisa MacDonald.jpg
----Kiú-kiong.jpg
----Elissa Hunter-Dorans.jpg
----Shengchi Hsu.jpg
----Will Buckingham.jpg


CREDITS:

Wind&Bones Images: © Wind&Bones 2025
Book Cover: © Wind&Bones 2025
Author Photos: © their respective authors 2025

CONTACT:

Hannah Stevens and Will Buckingham on contact@windandbones.com
Personal e-mails: h.stevens@live.co.uk / will@willbuckingham.com 
Wind&Bones Website: https://www.windandbones.com
Tâigael Website: https://taigael.com


Wind&Bones CIC
3/L 48 Cleghorn Street
Dundee. DD2 2NJ
Scotland
Company no. SC734907

