FOLDER CONTENTS:

--README.txt
--Taigael-Press Release-en.pdf [英文 / English]
--Taigael-Press Release-zw.pdf [中文 / Chinese]
--About Wind&Bones.pdf

--Wind&Bones Images [SUB-FOLDER]
----Taiwan Literature Base Residency Poster.jpeg
----logo-2025.png
----logo-2025-muted.png
----Hannah Stevens and Will Buckingham.jpeg
----Hannah Stevens and Will Buckingham 1.jpeg

--Website Images [SUB-FOLDER]
----website-preview.jpg
----front-page-image.jpg

--Scottish Connections Logos and Assets [SUB-FOLDER]
----Scottish Connections Fund 2024-25 4-5 - Tartan.jpg
----Scotland_Emblem_RGB.jpg
----Scotland_Emblem_CMYK.jpg
----Scotland_Emblem_Black.jpg

--Book Cover [SUB-FOLDER]
---Taigael Book Cover.jpg

--Author Photos [SUB-FOLDER]
----Naomi Sim.jpg
----Lisa MacDonald.jpg
----Kiú-kiong.jpg
----Elissa Hunter-Dorans.jpg


CREDITS:

Wind&Bones Images: © Wind&Bones 2025
Website Images: © Wind&Bones 2025
Scottish Connections Logos and Assets: © Scottish Connections Fund
Book Cover: © Wind&Bones 2025
Author Photos: © their respective authors 2025

CONTACT:

Hannah Stevens and Will Buckingham on contact@windandbones.com
Personal e-mails: h.stevens@live.co.uk / will@willbuckingham.com 
Wind&Bones Website: https://www.windandbones.com
Tâigael Website: https://taigael.com
Scottish Connections Fund Web-page: https://www.gov.scot/publications/scottish-connections-fund-successful-applicants/


Wind&Bones CIC
3/L 48 Cleghorn Street
Dundee. DD2 2NJ
Scotland
Company no. SC734907

